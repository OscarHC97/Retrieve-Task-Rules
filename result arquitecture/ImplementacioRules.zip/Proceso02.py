class Proceso02:
    def __init__(self):
        self.id_plan =20087
    def entrada (self):
        self.id_plan =20087
    def salida(self):
        return self.id_plan


import numpy as np
import random
from Proceso01 import Proceso01
def array_diff(a, b):
    for i in b:
        for j in range(len(a)):
             if i in a:
                 a.remove(i)

                 
    bandera  = False
    value = 7
    res = 0
    long = len(str(value))
    print(long)
    value = str(value)
    for i in value:
        res = res + pow(int(i),long)
        print(res)
    if res == int(value):
        bandera = True
    else:
        bandera  =False
    print(bandera)
    return bandera

    #return a
   # return [x for x in a if x not in b]
#array_diff([1,2],[1,2])
#array_diff([1,2,2], [2])
'''
    print(a)
    for i in b:
        for j in a:
            a.remove(i)
            print(a)'''
  

   

#print(array_diff([1,2,2,2,3],[2,3]))

def encargar(ruleMTL, ruleIDA):
    vector = [] #id de rules MTL
    vector2 = [] #id de rules IDA
    vector3 = [] #reglas diferentes
    for i in ruleMTL:
        vector.append(i[0])
    for j in ruleIDA:
        vector2.append(j[0])

    dif  = set(vector2) - set(vector)  #obtener la diferiencia
    #dif2 = set(vector)  -  set(vector2)
    print (vector," vector 2 :", vector2)
    print("Difer: ",dif)
    #print("Difer2: ", dif2)
    for i in ruleIDA:    #filtra las reglas diferentes para obtener su priority
        for j in dif:
            if i[0] == j:
              vector3.append(i)
    print(vector3)

#encargar([(1,22),(2,34),(3,22),(5,22)],[(1,22),(2,22),(3,22),(4,33),(6,22)])

def ramdome(): #Prueva de random randint 0 1
    while 5:
        a  = random.randint(0,1)
        print(a)


def entradaLeerMatrix(matriz):
    k = 0
    print(matriz)
    recompenzavector = []

    for i in matriz:
        recompenzavector.append(((i[0] + i[1])/2))
        print(recompenzavector[k],k)
        k +=1
'''
p1 = Proceso01()
#Process 10 simulation--------
ran1 = random.randrange(1,16)
ran2 = random.randint(0,1)

#process 1 simularion--------
print("rule: ", ran1, " Recom: ",ran2)
p1.Entrada(ran1,ran2)      
matrizz = p1.Salida() 

entradaLeerMatrix(matrizz)

'''



def decodificadormorce(message):
    diccionary = {'A':'.-', 'B':'-...', 'C':'-.-.',
                  'D':'-..','E':'.','F':'..-.',
                  'G':'--.','H':'....','I':'..',
                  'J':'.---','K':'-.-','L':'.-..',
                  'M':'--','N':'-.','O':'---',
                  'P':'.--.','Q':'--.-','R':'.-.',
                  'S':'...','T':'-','U':'..-',
                  'V':'...-','W':'.--','X':'-..-',
                  'Y':'-.--', 'Z':'--..',' ':'.......'}
    desencrypt = {v:k for k,v in diccionary.items()}
    #print(desencrypt)
    text  = ''.join(desencrypt[i] for i in message.split())
    return text
#print(decodificadormorce('... --- ...'))


def tribonacci(signature, n): #numerosiniciales, num_ensayos
    lisst=[]
    for i in range(n):
          sum = signature[i] +signature[i+1] + signature[i+2]
          signature.append(sum)

    for i in range(n):
        lisst.append(signature[i])

    return lisst

#print(tribonacci([300, 200, 100], 1))


def order(sentence):
    a =[]
    b =[]
    lisst = ["1","2","3","4","5","6","7","8","9"]
    for i in sentence.split():
        a.append(i)

    for i in range(len(lisst)):
        
        for j in a:
           
            if lisst[i] in j:
                b.append(j)
    b= " ".join(b)
    return b
#print(order("4of Fo1r pe6ople g3ood th5e the2"))
def anagrams(word, words):
     return [item for item in words if sorted(item)==sorted(word)]
    
#print(anagrams('abba', ['aabb', 'abcd', 'bbaa', 'dada']))
def sapara(serarable):
    a =[]
    #a.append(serarable.split("A"))
 
    for i in range(len(serarable)):
        b = i+1
        print(b)
        if b > len(serarable):
            aux =serarable[i]
        else:
            aux = serarable[i+1]
        
        
        if serarable[i] == aux:
            a.append(serarable[i])
    print (a)
    return a
sapara('AAAABBBCCDAABBB')


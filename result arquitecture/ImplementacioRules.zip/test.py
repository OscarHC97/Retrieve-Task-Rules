from Proceso01 import Proceso01

def main():
    
    p1 = Proceso01()

    print(p1.Similar(0,0,0))
    print(p1.Similar(0,0,1))
    print(p1.Similar(0,1,0))
    print(p1.Similar(0,1,1))
    print(p1.Similar(1,0,0))
    print(p1.Similar(1,0,1))
    print(p1.Similar(1,1,0))
    print(p1.Similar(1,1,1))





if __name__ == "__main__":
    main()
     